/*
# Drop profiles FK to auth.users + seed demo students

1. Drops the foreign key constraint `profiles_id_fkey` so demo student profiles
   (not linked to auth.users) can coexist with real user profiles in the same table.
   The handle_new_user trigger still correctly creates real user profiles on signup.
2. Seeds 8 realistic demo student profiles with skills, ratings, and credit balances.
3. Adds sample credit transactions and completed help requests for history realism.
*/

ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

DO $$
DECLARE
  s1 uuid := gen_random_uuid();
  s2 uuid := gen_random_uuid();
  s3 uuid := gen_random_uuid();
  s4 uuid := gen_random_uuid();
  s5 uuid := gen_random_uuid();
  s6 uuid := gen_random_uuid();
  s7 uuid := gen_random_uuid();
  s8 uuid := gen_random_uuid();
  r1 uuid;
  r2 uuid;
BEGIN
  INSERT INTO profiles (id, email, full_name, avatar_url, education_level, city, skills_teach, skills_learn, bio, skill_credits, rating_avg, rating_count, onboarded)
  VALUES
    (s1, 'ananya.demo@studyswap.in', 'Ananya Sharma', '', 'Class 12', 'Mumbai',
     ARRAY['Mathematics','Physics','Chemistry'], ARRAY['Computer Science','English'],
     'PCM student preparing for JEE. Love breaking down tough problems into simple steps.', 85, 4.8, 12, true),
    (s2, 'rahul.demo@studyswap.in', 'Rahul Verma', '', 'Undergraduate', 'Delhi',
     ARRAY['Computer Science','Python','Web Development'], ARRAY['Mathematics','Statistics'],
     'B.Tech CS student. Can teach coding from scratch to advanced projects.', 120, 4.9, 18, true),
    (s3, 'priya.demo@studyswap.in', 'Priya Nair', '', 'Class 11', 'Bengaluru',
     ARRAY['Biology','Chemistry','English'], ARRAY['Physics','Mathematics'],
     'Aspiring doctor. NEET aspirant with strong fundamentals in Bio & Chem.', 60, 4.6, 8, true),
    (s4, 'arjun.demo@studyswap.in', 'Arjun Reddy', '', 'Undergraduate', 'Hyderabad',
     ARRAY['Economics','Business Studies','Accountancy'], ARRAY['Computer Science'],
     'B.Com student. Numbers are my thing. Can make accounting fun, promise!', 45, 4.3, 5, true),
    (s5, 'ishaan.demo@studyswap.in', 'Ishaan Gupta', '', 'Class 12', 'Pune',
     ARRAY['Mathematics','Physics','Computer Science'], ARRAY['Chemistry','Biology'],
     'JEE aspirant + coding enthusiast. Math is life.', 95, 4.7, 14, true),
    (s6, 'meera.demo@studyswap.in', 'Meera Iyer', '', 'Undergraduate', 'Chennai',
     ARRAY['English','History','Political Science'], ARRAY['Economics','Mathematics'],
     'BA English Literature. Wordsmith. Can help with essays, writing, and humanities.', 70, 4.5, 10, true),
    (s7, 'karan.demo@studyswap.in', 'Karan Singh', '', 'Class 11', 'Jaipur',
     ARRAY['Physics','Mathematics','Chemistry'], ARRAY['English','Computer Science'],
     'Science geek. Love teaching concepts with real-world analogies.', 55, 4.4, 6, true),
    (s8, 'sneha.demo@studyswap.in', 'Sneha Patel', '', 'Undergraduate', 'Ahmedabad',
     ARRAY['Statistics','Data Science','Python'], ARRAY['Business Studies','Economics'],
     'Data science major. I make statistics less scary.', 80, 4.6, 9, true)
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO credit_transactions (profile_id, amount, type, description)
  VALUES
    (s1, 50, 'bonus', 'Welcome bonus credits'),
    (s1, 15, 'earned', 'Helped Karan with Mathematics'),
    (s1, -5, 'spent', 'Got help from Rahul with Python'),
    (s2, 50, 'bonus', 'Welcome bonus credits'),
    (s2, 20, 'earned', 'Helped Ananya with Computer Science')
  ON CONFLICT DO NOTHING;

  r1 := gen_random_uuid();
  r2 := gen_random_uuid();
  INSERT INTO help_requests (id, sender_id, receiver_id, subject, message, status, skill_credits)
  VALUES
    (r1, s7, s1, 'Mathematics', 'Need help with calculus derivatives', 'completed', 5),
    (r2, s1, s2, 'Python', 'Can you teach me basics of Python loops?', 'completed', 5)
  ON CONFLICT DO NOTHING;

  INSERT INTO ratings (request_id, rater_id, ratee_id, score)
  VALUES
    (r1, s7, s1, 5),
    (r2, s1, s2, 5)
  ON CONFLICT DO NOTHING;
END $$;
