/*
# StudySwap — Full Schema

1. Overview
StudySwap is a student-to-student learning platform. Students exchange help using
"Skill Credits" instead of money. Helping earns credits; requesting help costs credits.

2. New Tables
- `profiles` — student profile data linked to auth.users (name, avatar, education level, city, bio, skill_credit_balance, rating)
- `help_requests` — requests one student sends to another for help with a subject; has status (pending/accepted/rejected/completed)
- `credit_transactions` — ledger of credit changes (earned/spent) per profile
- `ratings` — rating a student gives another after a completed help session

3. RLS
- This app has sign-in, so policies are `TO authenticated` with ownership predicates.
- profiles: each user reads/writes only their own profile row, but ALL profiles are readable (needed for matching). So SELECT is open to authenticated, UPDATE only own row.
- help_requests: a user can read requests they sent or received; can insert only as sender; can update status only as receiver (accept/reject) or sender (cancel/complete-as-requester); can delete own sent requests.
- credit_transactions: read only own; insert handled by RPC (SECURITY DEFINER) so RLS on insert is restrictive.
- ratings: read all (for displaying on profiles); insert only as rater for a request they're part of.

4. RPC Functions (SECURITY DEFINER)
- `accept_help_request(req_id)` — receiver accepts; deducts credits from sender, will be transferred on completion.
- `complete_help_request(req_id)` — receiver marks complete; transfers credits to receiver, creates transaction rows.
- `reject_help_request(req_id)` — receiver rejects.
- `cancel_help_request(req_id)` — sender cancels a pending request.
- `rate_help_request(req_id, score)` — rater rates the other party; updates profile rating aggregate.
- `spend_credits_on_request(req_id)` — internal helper used at accept time.

5. Notes
- New users get 50 starter credits (set in profile default and in signup trigger).
- A rating trigger updates profile rating_avg & rating_count after each rating insert.
*/

-- ============ profiles ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  avatar_url text DEFAULT '',
  education_level text DEFAULT '',
  city text DEFAULT '',
  skills_teach text[] DEFAULT '{}',
  skills_learn text[] DEFAULT '{}',
  bio text DEFAULT '',
  skill_credits integer NOT NULL DEFAULT 50,
  rating_avg numeric(2,1) NOT NULL DEFAULT 0.0,
  rating_count integer NOT NULL DEFAULT 0,
  onboarded boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_all" ON profiles;
CREATE POLICY "profiles_select_all"
ON profiles FOR SELECT
TO authenticated USING (true);

DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own"
ON profiles FOR INSERT
TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own"
ON profiles FOR UPDATE
TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============ help_requests ============
CREATE TABLE IF NOT EXISTS help_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  receiver_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  subject text NOT NULL,
  message text DEFAULT '',
  status text NOT NULL DEFAULT 'pending',
  skill_credits integer NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE help_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "requests_select_parties" ON help_requests;
CREATE POLICY "requests_select_parties"
ON help_requests FOR SELECT
TO authenticated USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

DROP POLICY IF EXISTS "requests_insert_sender" ON help_requests;
CREATE POLICY "requests_insert_sender"
ON help_requests FOR INSERT
TO authenticated WITH CHECK (auth.uid() = sender_id);

DROP POLICY IF EXISTS "requests_update_parties" ON help_requests;
CREATE POLICY "requests_update_parties"
ON help_requests FOR UPDATE
TO authenticated
USING (auth.uid() = sender_id OR auth.uid() = receiver_id)
WITH CHECK (auth.uid() = sender_id OR auth.uid() = receiver_id);

DROP POLICY IF EXISTS "requests_delete_sender" ON help_requests;
CREATE POLICY "requests_delete_sender"
ON help_requests FOR DELETE
TO authenticated USING (auth.uid() = sender_id);

-- ============ credit_transactions ============
CREATE TABLE IF NOT EXISTS credit_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  type text NOT NULL,
  description text DEFAULT '',
  related_request_id uuid REFERENCES help_requests(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE credit_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "txn_select_own" ON credit_transactions;
CREATE POLICY "txn_select_own"
ON credit_transactions FOR SELECT
TO authenticated USING (auth.uid() = profile_id);

DROP POLICY IF EXISTS "txn_insert_own" ON credit_transactions;
CREATE POLICY "txn_insert_own"
ON credit_transactions FOR INSERT
TO authenticated WITH CHECK (auth.uid() = profile_id);

-- ============ ratings ============
CREATE TABLE IF NOT EXISTS ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES help_requests(id) ON DELETE CASCADE,
  rater_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  ratee_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  score integer NOT NULL CHECK (score >= 1 AND score <= 5),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ratings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ratings_select_all" ON ratings;
CREATE POLICY "ratings_select_all"
ON ratings FOR SELECT
TO authenticated USING (true);

DROP POLICY IF EXISTS "ratings_insert_party" ON ratings;
CREATE POLICY "ratings_insert_party"
ON ratings FOR INSERT
TO authenticated WITH CHECK (auth.uid() = rater_id);

-- ============ indexes ============
CREATE INDEX IF NOT EXISTS idx_requests_sender ON help_requests(sender_id);
CREATE INDEX IF NOT EXISTS idx_requests_receiver ON help_requests(receiver_id);
CREATE INDEX IF NOT EXISTS idx_requests_status ON help_requests(status);
CREATE INDEX IF NOT EXISTS idx_txn_profile ON credit_transactions(profile_id);
CREATE INDEX IF NOT EXISTS idx_profiles_skills_teach ON profiles USING gin(skills_teach);
CREATE INDEX IF NOT EXISTS idx_profiles_skills_learn ON profiles USING gin(skills_learn);

-- ============ trigger: updated_at ============
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profiles_updated ON profiles;
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON profiles
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_requests_updated ON help_requests;
CREATE TRIGGER trg_requests_updated BEFORE UPDATE ON help_requests
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ============ trigger: auto-create profile on signup ============
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, skill_credits)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), 50);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============ RPC: accept_help_request ============
-- Receiver accepts a pending request. Escrows credits from sender (deduct now, transfer on complete).
CREATE OR REPLACE FUNCTION accept_help_request(req_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  req help_requests%ROWTYPE;
  sender_balance integer;
BEGIN
  SELECT * INTO req FROM help_requests WHERE id = req_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request not found';
  END IF;
  IF req.receiver_id <> auth.uid() THEN
    RAISE EXCEPTION 'Only the receiver can accept';
  END IF;
  IF req.status <> 'pending' THEN
    RAISE EXCEPTION 'Request is not pending';
  END IF;

  SELECT skill_credits INTO sender_balance FROM profiles WHERE id = req.sender_id;
  IF sender_balance < req.skill_credits THEN
    RAISE EXCEPTION 'Sender has insufficient credits';
  END IF;

  -- Escrow: deduct from sender now
  UPDATE profiles SET skill_credits = skill_credits - req.skill_credits WHERE id = req.sender_id;

  UPDATE help_requests SET status = 'accepted' WHERE id = req_id;
END;
$$;

-- ============ RPC: complete_help_request ============
-- Receiver marks request complete. Transfers escrowed credits to receiver.
CREATE OR REPLACE FUNCTION complete_help_request(req_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  req help_requests%ROWTYPE;
BEGIN
  SELECT * INTO req FROM help_requests WHERE id = req_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request not found';
  END IF;
  IF req.receiver_id <> auth.uid() THEN
    RAISE EXCEPTION 'Only the receiver can complete';
  END IF;
  IF req.status <> 'accepted' THEN
    RAISE EXCEPTION 'Request must be accepted first';
  END IF;

  -- Transfer escrowed credits to receiver
  UPDATE profiles SET skill_credits = skill_credits + req.skill_credits WHERE id = req.receiver_id;

  UPDATE help_requests SET status = 'completed' WHERE id = req_id;

  -- Record transactions
  INSERT INTO credit_transactions (profile_id, amount, type, description, related_request_id)
  VALUES (req.sender_id, -req.skill_credits, 'spent', 'Help received: ' || req.subject, req.id);
  INSERT INTO credit_transactions (profile_id, amount, type, description, related_request_id)
  VALUES (req.receiver_id, req.skill_credits, 'earned', 'Help provided: ' || req.subject, req.id);
END;
$$;

-- ============ RPC: reject_help_request ============
CREATE OR REPLACE FUNCTION reject_help_request(req_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  req help_requests%ROWTYPE;
BEGIN
  SELECT * INTO req FROM help_requests WHERE id = req_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request not found';
  END IF;
  IF req.receiver_id <> auth.uid() THEN
    RAISE EXCEPTION 'Only the receiver can reject';
  END IF;
  IF req.status <> 'pending' THEN
    RAISE EXCEPTION 'Request is not pending';
  END IF;
  UPDATE help_requests SET status = 'rejected' WHERE id = req_id;
END;
$$;

-- ============ RPC: cancel_help_request ============
CREATE OR REPLACE FUNCTION cancel_help_request(req_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  req help_requests%ROWTYPE;
BEGIN
  SELECT * INTO req FROM help_requests WHERE id = req_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request not found';
  END IF;
  IF req.sender_id <> auth.uid() THEN
    RAISE EXCEPTION 'Only the sender can cancel';
  END IF;
  IF req.status NOT IN ('pending','accepted') THEN
    RAISE EXCEPTION 'Cannot cancel this request';
  END IF;
  -- If was accepted, refund escrowed credits to sender
  IF req.status = 'accepted' THEN
    UPDATE profiles SET skill_credits = skill_credits + req.skill_credits WHERE id = req.sender_id;
  END IF;
  UPDATE help_requests SET status = 'cancelled' WHERE id = req_id;
END;
$$;

-- ============ RPC: rate_help_request ============
-- Rater rates the other party. Updates the ratee's aggregate rating.
CREATE OR REPLACE FUNCTION rate_help_request(req_id uuid, score integer)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  req help_requests%ROWTYPE;
  ratee uuid;
  existing_count integer;
  new_avg numeric;
BEGIN
  IF score < 1 OR score > 5 THEN
    RAISE EXCEPTION 'Score must be between 1 and 5';
  END IF;
  SELECT * INTO req FROM help_requests WHERE id = req_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request not found';
  END IF;
  IF req.status <> 'completed' THEN
    RAISE EXCEPTION 'Can only rate completed requests';
  END IF;
  -- Determine ratee: the opposite party
  IF auth.uid() = req.sender_id THEN
    ratee := req.receiver_id;
  ELSIF auth.uid() = req.receiver_id THEN
    ratee := req.sender_id;
  ELSE
    RAISE EXCEPTION 'Not a party to this request';
  END IF;
  -- Prevent double rating
  IF EXISTS (SELECT 1 FROM ratings WHERE request_id = req_id AND rater_id = auth.uid()) THEN
    RAISE EXCEPTION 'Already rated';
  END IF;

  INSERT INTO ratings (request_id, rater_id, ratee_id, score) VALUES (req_id, auth.uid(), ratee, score);

  -- Recompute ratee aggregate
  SELECT rating_count INTO existing_count FROM profiles WHERE id = ratee;
  SELECT COALESCE(AVG(score), 0) INTO new_avg FROM ratings WHERE ratee_id = ratee;
  UPDATE profiles
  SET rating_avg = new_avg, rating_count = existing_count + 1
  WHERE id = ratee;
END;
$$;

-- ============ RPC: get_matched_students ============
-- Returns recommended students for the current user based on skill overlap.
CREATE OR REPLACE FUNCTION get_matched_students()
RETURNS TABLE (
  id uuid,
  full_name text,
  avatar_url text,
  education_level text,
  city text,
  skills_teach text[],
  skills_learn text[],
  bio text,
  rating_avg numeric,
  rating_count integer,
  match_score integer
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  my_learn text[];
  my_teach text[];
  my_city text;
  my_edu text;
BEGIN
  SELECT skills_learn, skills_teach, city, education_level
  INTO my_learn, my_teach, my_city, my_edu
  FROM profiles WHERE id = auth.uid();

  RETURN QUERY
  SELECT
    p.id,
    p.full_name,
    p.avatar_url,
    p.education_level,
    p.city,
    p.skills_teach,
    p.skills_learn,
    p.bio,
    p.rating_avg,
    p.rating_count,
    (
      (CASE WHEN array_length(p.skills_teach && my_learn, 1) IS NOT NULL
            THEN array_length(p.skills_teach && my_learn, 1) ELSE 0 END) * 5
      +
      (CASE WHEN array_length(p.skills_learn && my_teach, 1) IS NOT NULL
            THEN array_length(p.skills_learn && my_teach, 1) ELSE 0 END) * 3
      +
      (CASE WHEN p.city = my_city AND my_city <> '' THEN 2 ELSE 0 END)
      +
      (CASE WHEN p.education_level = my_edu AND my_edu <> '' THEN 1 ELSE 0 END)
    ) AS match_score
  FROM profiles p
  WHERE p.id <> auth.uid()
    AND p.onboarded = true
  ORDER BY match_score DESC, p.rating_avg DESC NULLS LAST
  LIMIT 50;
END;
$$;
