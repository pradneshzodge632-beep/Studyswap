import { useEffect, useState } from 'react';
import { supabase, MatchedStudent, HelpRequest, Profile } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Avatar, CreditBadge, RatingStars, SkillTag } from '@/components/ui';
import { RequestHelpModal } from '@/components/RequestHelpModal';

type Page = 'dashboard' | 'find' | 'profile' | 'requests' | 'credits' | 'settings';

export function Dashboard({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const { profile, refreshProfile } = useAuth();
  const [matches, setMatches] = useState<MatchedStudent[]>([]);
  const [pendingReceived, setPendingReceived] = useState<(HelpRequest & { sender: Profile })[]>([]);
  const [pendingSent, setPendingSent] = useState<(HelpRequest & { receiver: Profile })[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalStudent, setModalStudent] = useState<MatchedStudent | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, [profile?.id]);

  const loadData = async () => {
    if (!profile) return;
    setLoading(true);

    const { data: matchData } = await supabase.rpc('get_matched_students');
    setMatches((matchData as MatchedStudent[]) || []);

    const { data: received } = await supabase
      .from('help_requests')
      .select('*, sender:profiles!help_requests_sender_id_fkey(*)')
      .eq('receiver_id', profile.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    setPendingReceived((received as any) || []);

    const { data: sent } = await supabase
      .from('help_requests')
      .select('*, receiver:profiles!help_requests_receiver_id_fkey(*)')
      .eq('sender_id', profile.id)
      .in('status', ['pending', 'accepted'])
      .order('created_at', { ascending: false });

    setPendingSent((sent as any) || []);
    setLoading(false);
  };

  const handleAccept = async (reqId: string) => {
    setActionLoading(reqId);
    const { error } = await supabase.rpc('accept_help_request', { req_id: reqId });
    setActionLoading(null);
    if (error) {
      alert(error.message);
      return;
    }
    await refreshProfile();
    loadData();
  };

  const handleReject = async (reqId: string) => {
    setActionLoading(reqId);
    const { error } = await supabase.rpc('reject_help_request', { req_id: reqId });
    setActionLoading(null);
    if (error) {
      alert(error.message);
      return;
    }
    loadData();
  };

  const firstName = profile?.full_name?.split(' ')[0] || 'there';

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="animate-fade-up">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">
          Hey, {firstName}!
        </h1>
        <p className="text-gray-400 mt-1">Here's what's happening on StudySwap today.</p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-up delay-100">
        <div className="glass rounded-2xl p-5 card-glow">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 font-medium">Skill Credits</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4-6.2-4.5-6.2 4.5 2.4-7.4L2 9.4h7.6z" />
              </svg>
            </div>
          </div>
          <div className="text-3xl font-bold gradient-text">{profile?.skill_credits ?? 0}</div>
        </div>

        <div className="glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 font-medium">Pending Requests</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 3v-3z" />
              </svg>
            </div>
          </div>
          <div className="text-3xl font-bold text-white">{pendingReceived.length}</div>
        </div>

        <div className="glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 font-medium">Sent Requests</span>
            <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </div>
          </div>
          <div className="text-3xl font-bold text-white">{pendingSent.length}</div>
        </div>

        <div className="glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 font-medium">Rating</span>
            <div className="w-8 h-8 rounded-lg bg-rose-500/15 border border-rose-500/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-rose-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            </div>
          </div>
          <div className="text-3xl font-bold text-white">
            {profile && profile.rating_avg > 0 ? profile.rating_avg.toFixed(1) : '—'}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 animate-fade-up delay-200">
        {[
          { label: 'Find Students', page: 'find' as Page, icon: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z' },
          { label: 'My Requests', page: 'requests' as Page, icon: 'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 3v-3z' },
          { label: 'Skill Credits', page: 'credits' as Page, icon: 'M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4-6.2-4.5-6.2 4.5 2.4-7.4L2 9.4h7.6z' },
          { label: 'Edit Profile', page: 'profile' as Page, icon: 'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z' },
        ].map((a) => (
          <button
            key={a.label}
            onClick={() => onNavigate(a.page)}
            className="glass glass-hover rounded-xl p-4 flex flex-col items-center gap-2 text-center"
          >
            <div className="w-10 h-10 rounded-lg bg-white/[0.04] flex items-center justify-center text-emerald-300">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d={a.icon} />
              </svg>
            </div>
            <span className="text-sm font-medium text-white">{a.label}</span>
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Pending requests */}
        <div className="glass rounded-2xl p-5 animate-fade-up delay-300">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-white">Pending Requests</h2>
            <button onClick={() => onNavigate('requests')} className="text-xs text-emerald-400 hover:underline">
              View all
            </button>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="h-16 rounded-xl bg-white/[0.02] animate-pulse" />
              ))}
            </div>
          ) : pendingReceived.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p className="text-sm">No pending requests right now.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingReceived.slice(0, 3).map((req) => (
                <div key={req.id} className="bg-white/[0.02] rounded-xl p-3 border border-white/[0.04]">
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar name={req.sender.full_name} url={req.sender.avatar_url || undefined} size="sm" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{req.sender.full_name}</p>
                      <p className="text-xs text-gray-500 truncate">Needs help with {req.subject}</p>
                    </div>
                    <CreditBadge amount={req.skill_credits} size="sm" />
                  </div>
                  {req.message && <p className="text-xs text-gray-400 mb-3 line-clamp-2">{req.message}</p>}
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleAccept(req.id)}
                      disabled={actionLoading === req.id}
                      className="flex-1 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold hover:bg-emerald-500/30 transition disabled:opacity-50"
                    >
                      {actionLoading === req.id ? '...' : 'Accept'}
                    </button>
                    <button
                      onClick={() => handleReject(req.id)}
                      disabled={actionLoading === req.id}
                      className="flex-1 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-gray-400 text-xs font-semibold hover:bg-rose-500/10 hover:text-rose-400 transition disabled:opacity-50"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recommended students */}
        <div className="glass rounded-2xl p-5 animate-fade-up delay-300">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-white">Recommended for You</h2>
            <button onClick={() => onNavigate('find')} className="text-xs text-emerald-400 hover:underline">
              View all
            </button>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="h-20 rounded-xl bg-white/[0.02] animate-pulse" />
              ))}
            </div>
          ) : matches.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p className="text-sm">Complete your profile to get matches.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {matches.slice(0, 3).map((m) => (
                <div key={m.id} className="bg-white/[0.02] rounded-xl p-3 border border-white/[0.04] hover:border-emerald-500/20 transition">
                  <div className="flex items-center gap-3 mb-2">
                    <Avatar name={m.full_name} url={m.avatar_url || undefined} size="md" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{m.full_name}</p>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <span>{m.education_level}</span>
                        <span>·</span>
                        <span>{m.city}</span>
                      </div>
                    </div>
                    <RatingStars rating={m.rating_avg} count={m.rating_count} />
                  </div>
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {m.skills_teach.slice(0, 3).map((s) => <SkillTag key={s} skill={s} variant="teach" />)}
                  </div>
                  <button
                    onClick={() => setModalStudent(m)}
                    className="w-full py-2 rounded-lg bg-emerald-500/15 border border-emerald-500/25 text-emerald-300 text-xs font-semibold hover:bg-emerald-500/25 transition"
                  >
                    Request Help
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {modalStudent && (
        <RequestHelpModal
          student={modalStudent}
          onClose={() => setModalStudent(null)}
          onSent={() => {
            setModalStudent(null);
            refreshProfile();
            loadData();
          }}
        />
      )}
    </div>
  );
}
