import { useEffect, useState } from 'react';
import { supabase, MatchedStudent } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Avatar, RatingStars, SkillTag } from '@/components/ui';
import { RequestHelpModal } from '@/components/RequestHelpModal';
import { SUBJECTS, EDUCATION_LEVELS, CITIES } from '@/lib/constants';

export function FindStudents() {
  const { profile } = useAuth();
  const [students, setStudents] = useState<MatchedStudent[]>([]);
  const [filtered, setFiltered] = useState<MatchedStudent[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [cityFilter, setCityFilter] = useState('');
  const [eduFilter, setEduFilter] = useState('');
  const [modalStudent, setModalStudent] = useState<MatchedStudent | null>(null);

  useEffect(() => {
    loadStudents();
  }, [profile?.id]);

  useEffect(() => {
    let result = students;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (s) =>
          s.full_name.toLowerCase().includes(q) ||
          s.bio.toLowerCase().includes(q) ||
          s.skills_teach.some((sk) => sk.toLowerCase().includes(q))
      );
    }
    if (subjectFilter) {
      result = result.filter((s) => s.skills_teach.includes(subjectFilter));
    }
    if (cityFilter) {
      result = result.filter((s) => s.city === cityFilter);
    }
    if (eduFilter) {
      result = result.filter((s) => s.education_level === eduFilter);
    }
    setFiltered(result);
  }, [students, search, subjectFilter, cityFilter, eduFilter]);

  const loadStudents = async () => {
    if (!profile) return;
    setLoading(true);
    const { data } = await supabase.rpc('get_matched_students');
    setStudents((data as MatchedStudent[]) || []);
    setFiltered((data as MatchedStudent[]) || []);
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="animate-fade-up">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">Find Students</h1>
        <p className="text-gray-400 mt-1">Discover peers who can help you — and who you can help.</p>
      </div>

      {/* Filters */}
      <div className="glass rounded-2xl p-4 space-y-3 animate-fade-up delay-100">
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, subject, or bio..."
            className="w-full bg-white/[0.04] border border-white/10 rounded-xl pl-10 pr-3 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <select
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            className="bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
          >
            <option value="" className="bg-[#0a0a0f]">All subjects</option>
            {SUBJECTS.map((s) => (
              <option key={s} value={s} className="bg-[#0a0a0f]">{s}</option>
            ))}
          </select>
          <select
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            className="bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
          >
            <option value="" className="bg-[#0a0a0f]">All cities</option>
            {CITIES.map((c) => (
              <option key={c} value={c} className="bg-[#0a0a0f]">{c}</option>
            ))}
          </select>
          <select
            value={eduFilter}
            onChange={(e) => setEduFilter(e.target.value)}
            className="bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
          >
            <option value="" className="bg-[#0a0a0f]">All levels</option>
            {EDUCATION_LEVELS.map((l) => (
              <option key={l} value={l} className="bg-[#0a0a0f]">{l}</option>
            ))}
          </select>
        </div>

        {(subjectFilter || cityFilter || eduFilter || search) && (
          <button
            onClick={() => { setSearch(''); setSubjectFilter(''); setCityFilter(''); setEduFilter(''); }}
            className="text-xs text-gray-400 hover:text-white transition"
          >
            Clear filters
          </button>
        )}
      </div>

      {/* Results count */}
      <div className="text-sm text-gray-500">
        {loading ? 'Loading...' : `${filtered.length} student${filtered.length !== 1 ? 's' : ''} found`}
      </div>

      {/* Student cards */}
      {loading ? (
        <div className="grid sm:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-48 rounded-2xl bg-white/[0.02] animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="glass rounded-2xl p-12 text-center">
          <p className="text-gray-400">No students match your filters.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {filtered.map((s, i) => (
            <div
              key={s.id}
              className="glass glass-hover rounded-2xl p-5 animate-fade-up"
              style={{ animationDelay: `${Math.min(i * 0.05, 0.3)}s` }}
            >
              <div className="flex items-start gap-4 mb-4">
                <Avatar name={s.full_name} url={s.avatar_url || undefined} size="lg" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-white truncate">{s.full_name}</h3>
                    {s.match_score > 0 && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/25 text-emerald-300 font-medium">
                        {s.match_score > 8 ? 'Great match' : s.match_score > 4 ? 'Good match' : 'Match'}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                    <span>{s.education_level}</span>
                    <span>·</span>
                    <span>{s.city}</span>
                  </div>
                  <div className="mt-1.5">
                    <RatingStars rating={s.rating_avg} count={s.rating_count} />
                  </div>
                </div>
              </div>

              {s.bio && <p className="text-sm text-gray-400 mb-3 line-clamp-2">{s.bio}</p>}

              {s.skills_teach.length > 0 && (
                <div className="mb-3">
                  <p className="text-xs text-gray-500 mb-1.5">Can teach:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {s.skills_teach.map((sk) => <SkillTag key={sk} skill={sk} variant="teach" />)}
                  </div>
                </div>
              )}

              {s.skills_learn.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs text-gray-500 mb-1.5">Needs help with:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {s.skills_learn.map((sk) => <SkillTag key={sk} skill={sk} variant="learn" />)}
                  </div>
                </div>
              )}

              <button
                onClick={() => setModalStudent(s)}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 text-emerald-300 text-sm font-semibold hover:from-emerald-500/30 hover:to-teal-500/30 transition"
              >
                Request Help
              </button>
            </div>
          ))}
        </div>
      )}

      {modalStudent && (
        <RequestHelpModal
          student={modalStudent}
          onClose={() => setModalStudent(null)}
          onSent={() => {
            setModalStudent(null);
          }}
        />
      )}
    </div>
  );
}
