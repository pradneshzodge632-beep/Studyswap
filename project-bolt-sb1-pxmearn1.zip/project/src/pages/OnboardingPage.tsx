import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { SUBJECTS, EDUCATION_LEVELS, CITIES } from '@/lib/constants';
import { SkillTag } from '@/components/ui';

export function OnboardingPage({ onComplete }: { onComplete: () => void }) {
  const { user, profile, refreshProfile } = useAuth();
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [avatarUrl, setAvatarUrl] = useState(profile?.avatar_url || '');
  const [educationLevel, setEducationLevel] = useState(profile?.education_level || '');
  const [city, setCity] = useState(profile?.city || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [skillsTeach, setSkillsTeach] = useState<string[]>(profile?.skills_teach || []);
  const [skillsLearn, setSkillsLearn] = useState<string[]>(profile?.skills_learn || []);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleSkill = (skill: string, list: string[], setter: (v: string[]) => void) => {
    setter(list.includes(skill) ? list.filter((s) => s !== skill) : [...list, skill]);
  };

  const handleSave = async () => {
    if (!user) return;
    if (!fullName.trim()) {
      setError('Please enter your name');
      return;
    }
    if (!educationLevel) {
      setError('Please select your education level');
      return;
    }
    if (!city) {
      setError('Please select your city');
      return;
    }
    if (skillsTeach.length === 0 && skillsLearn.length === 0) {
      setError('Add at least one skill to teach or learn');
      return;
    }

    setSaving(true);
    setError(null);
    const { error: e } = await supabase
      .from('profiles')
      .update({
        full_name: fullName,
        avatar_url: avatarUrl,
        education_level: educationLevel,
        city,
        bio,
        skills_teach: skillsTeach,
        skills_learn: skillsLearn,
        onboarded: true,
      })
      .eq('id', user.id);

    setSaving(false);
    if (e) {
      setError(e.message);
      return;
    }
    await refreshProfile();
    onComplete();
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white py-8 px-4 relative overflow-hidden">
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px]" />

      <div className="relative max-w-2xl mx-auto">
        <div className="text-center mb-8 animate-fade-up">
          <h1 className="text-3xl font-bold">Set up your profile</h1>
          <p className="mt-2 text-gray-400">Tell us about yourself so we can find your perfect study partners.</p>
        </div>

        <div className="glass rounded-2xl p-6 sm:p-8 space-y-6 animate-fade-up delay-100">
          {/* Name */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Full Name</label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Your name"
              className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition"
            />
          </div>

          {/* Avatar URL */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Profile Picture URL (optional)</label>
            <input
              type="url"
              value={avatarUrl}
              onChange={(e) => setAvatarUrl(e.target.value)}
              placeholder="https://..."
              className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition"
            />
          </div>

          {/* Education + City */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1.5">Education Level</label>
              <select
                value={educationLevel}
                onChange={(e) => setEducationLevel(e.target.value)}
                className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
              >
                <option value="" className="bg-[#0a0a0f]">Select level</option>
                {EDUCATION_LEVELS.map((l) => (
                  <option key={l} value={l} className="bg-[#0a0a0f]">{l}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1.5">City</label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
              >
                <option value="" className="bg-[#0a0a0f]">Select city</option>
                {CITIES.map((c) => (
                  <option key={c} value={c} className="bg-[#0a0a0f]">{c}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Skills to teach */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-2">
              Subjects you can teach
              <span className="text-gray-600 ml-1">({skillsTeach.length} selected)</span>
            </label>
            <div className="flex flex-wrap gap-2">
              {SUBJECTS.map((s) => (
                <button
                  key={s}
                  onClick={() => toggleSkill(s, skillsTeach, setSkillsTeach)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                    skillsTeach.includes(s)
                      ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                      : 'bg-white/[0.03] border-white/10 text-gray-400 hover:border-white/20'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Skills to learn */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-2">
              Subjects you need help with
              <span className="text-gray-600 ml-1">({skillsLearn.length} selected)</span>
            </label>
            <div className="flex flex-wrap gap-2">
              {SUBJECTS.map((s) => (
                <button
                  key={s}
                  onClick={() => toggleSkill(s, skillsLearn, setSkillsLearn)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                    skillsLearn.includes(s)
                      ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                      : 'bg-white/[0.03] border-white/10 text-gray-400 hover:border-white/20'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Bio */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Short Bio (optional)</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              maxLength={200}
              placeholder="Tell other students about yourself..."
              className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition resize-none"
            />
            <p className="text-xs text-gray-600 mt-1">{bio.length}/200</p>
          </div>

          {/* Preview */}
          {(skillsTeach.length > 0 || skillsLearn.length > 0) && (
            <div className="bg-white/[0.02] rounded-xl p-4 border border-white/[0.06]">
              <p className="text-xs text-gray-500 mb-2">Preview:</p>
              <div className="flex flex-wrap gap-1.5">
                {skillsTeach.map((s) => <SkillTag key={s} skill={s} variant="teach" />)}
                {skillsLearn.map((s) => <SkillTag key={s} skill={s} variant="learn" />)}
              </div>
            </div>
          )}

          {error && (
            <div className="text-sm text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-xl px-3 py-2">
              {error}
            </div>
          )}

          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold hover:from-emerald-400 hover:to-teal-400 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? 'Saving...' : 'Complete Profile'}
          </button>
        </div>
      </div>
    </div>
  );
}
