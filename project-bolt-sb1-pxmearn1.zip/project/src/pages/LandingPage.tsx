import { useAuth } from '@/context/AuthContext';

export function LandingPage({ onGetStarted, onFindPartner }: { onGetStarted: () => void; onFindPartner: () => void }) {
  const { session } = useAuth();

  const features = [
    {
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.5 3.5 8.5 2 6 2 3.5 2 1.5 3.5 0 6.253 1.5 9 3.5 10.5 6 10.5c2.5 0 4.5-1.5 6-4.247zM12 6.253C13.5 3.5 15.5 2 18 2c2.5 0 4.5 1.5 6 4.253C22.5 9 20.5 10.5 18 10.5c-2.5 0-4.5-1.5-6-4.247z" />
        </svg>
      ),
      title: 'Skill-Based Matching',
      desc: 'Find students who can teach what you need and want to learn what you know. Smart matching based on subjects, level, and city.',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4-6.2-4.5-6.2 4.5 2.4-7.4L2 9.4h7.6z" />
        </svg>
      ),
      title: 'Skill Credits',
      desc: 'No money involved. Help a peer and earn Skill Credits. Use them to get help when you need it. Everyone starts with 50 free credits.',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      title: 'Student Community',
      desc: 'Connect with students across India. Build your reputation with ratings, track your progress, and grow together.',
    },
  ];

  const steps = [
    { num: '01', title: 'Create your profile', desc: 'Add your subjects, skills, and what you need help with.' },
    { num: '02', title: 'Find a match', desc: 'Browse recommended students based on complementary skills.' },
    { num: '03', title: 'Swap knowledge', desc: 'Send a request, get help, and earn Skill Credits by helping others.' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white overflow-x-hidden">
      {/* Background effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px]" />
      </div>

      {/* Nav */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 max-w-7xl mx-auto">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.5 3.5 8.5 2 6 2C3.5 2 1.5 3.5 0 6.253C1.5 9 3.5 10.5 6 10.5c2.5 0 4.5-1.5 6-4.247zM12 6.253C13.5 3.5 15.5 2 18 2c2.5 0 4.5 1.5 6 4.253C22.5 9 20.5 10.5 18 10.5c-2.5 0-4.5-1.5-6-4.247z" />
            </svg>
          </div>
          <span className="text-lg font-bold">StudySwap</span>
        </div>
        <button
          onClick={onGetStarted}
          className="px-4 py-2 rounded-xl text-sm font-medium text-white bg-white/[0.06] border border-white/10 hover:bg-white/[0.1] transition"
        >
          {session ? 'Go to Dashboard' : 'Sign In'}
        </button>
      </nav>

      {/* Hero */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 pt-20 pb-32 text-center">
        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-medium mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Learn without spending money
          </div>
        </div>

        <h1 className="animate-fade-up delay-100 text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight max-w-4xl mx-auto">
          Learn together. <span className="gradient-text">Grow together.</span>
        </h1>

        <p className="animate-fade-up delay-200 mt-6 text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Exchange knowledge with students, earn Skill Credits, and get help with the subjects you struggle with.
        </p>

        <div className="animate-fade-up delay-300 mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onGetStarted}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold hover:from-emerald-400 hover:to-teal-400 transition animate-pulse-glow"
          >
            Get Started
          </button>
          <button
            onClick={onFindPartner}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl glass glass-hover text-white font-semibold"
          >
            Find a Study Partner
          </button>
        </div>

        {/* Stats */}
        <div className="animate-fade-up delay-500 mt-20 grid grid-cols-3 gap-4 sm:gap-8 max-w-2xl mx-auto">
          {[
            { num: '8+', label: 'Subjects' },
            { num: '50', label: 'Free Credits' },
            { num: '100%', label: 'Student-Led' },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <div className="text-2xl sm:text-4xl font-bold gradient-text">{s.num}</div>
              <div className="text-xs sm:text-sm text-gray-500 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="relative z-10 max-w-6xl mx-auto px-6 pb-32">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold">How StudySwap works</h2>
          <p className="mt-4 text-gray-400 max-w-xl mx-auto">
            A peer-to-peer learning platform built for students, by students. No tutors, no fees — just knowledge sharing.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="glass glass-hover rounded-2xl p-6 card-glow"
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-emerald-500/20 flex items-center justify-center text-emerald-300 mb-4">
                {f.icon}
              </div>
              <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
              <p className="text-sm text-gray-400 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Steps */}
      <section className="relative z-10 max-w-4xl mx-auto px-6 pb-32">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold">Get started in 3 steps</h2>
        </div>
        <div className="space-y-6">
          {steps.map((s, i) => (
            <div key={s.num} className="flex items-start gap-5 glass rounded-2xl p-6">
              <div className="text-3xl font-bold gradient-text shrink-0">{s.num}</div>
              <div>
                <h3 className="text-lg font-semibold">{s.title}</h3>
                <p className="text-sm text-gray-400 mt-1">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative z-10 max-w-4xl mx-auto px-6 pb-32">
        <div className="glass rounded-3xl p-12 text-center card-glow relative overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-emerald-500/15 rounded-full blur-[80px]" />
          <div className="relative">
            <h2 className="text-3xl sm:text-4xl font-bold">Ready to start learning?</h2>
            <p className="mt-4 text-gray-400">Join StudySwap today and get 50 free Skill Credits.</p>
            <button
              onClick={onGetStarted}
              className="mt-8 px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold hover:from-emerald-400 hover:to-teal-400 transition"
            >
              Create Free Account
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/[0.06] py-8 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.5 3.5 8.5 2 6 2C3.5 2 1.5 3.5 0 6.253C1.5 9 3.5 10.5 6 10.5c2.5 0 4.5-1.5 6-4.247zM12 6.253C13.5 3.5 15.5 2 18 2c2.5 0 4.5 1.5 6 4.253C22.5 9 20.5 10.5 18 10.5c-2.5 0-4.5-1.5-6-4.247z" />
              </svg>
            </div>
            <span className="font-bold text-sm">StudySwap</span>
          </div>
          <p className="text-xs text-gray-500">Built for students across India. Learn together, grow together.</p>
        </div>
      </footer>
    </div>
  );
}
