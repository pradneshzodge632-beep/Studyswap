import { useEffect, useState } from 'react';
import { supabase, HelpRequest, Profile } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Avatar, CreditBadge, RatingStars } from '@/components/ui';

type ReqWithProfiles = HelpRequest & {
  sender: Profile;
  receiver: Profile;
};

export function Requests() {
  const { profile, refreshProfile } = useAuth();
  const [tab, setTab] = useState<'received' | 'sent'>('received');
  const [received, setReceived] = useState<ReqWithProfiles[]>([]);
  const [sent, setSent] = useState<ReqWithProfiles[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [ratingModal, setRatingModal] = useState<ReqWithProfiles | null>(null);
  const [ratingScore, setRatingScore] = useState(5);

  useEffect(() => {
    loadRequests();
  }, [profile?.id]);

  const loadRequests = async () => {
    if (!profile) return;
    setLoading(true);

    const [recRes, sentRes] = await Promise.all([
      supabase
        .from('help_requests')
        .select('*, sender:profiles!help_requests_sender_id_fkey(*), receiver:profiles!help_requests_receiver_id_fkey(*)')
        .eq('receiver_id', profile.id)
        .order('created_at', { ascending: false }),
      supabase
        .from('help_requests')
        .select('*, sender:profiles!help_requests_sender_id_fkey(*), receiver:profiles!help_requests_receiver_id_fkey(*)')
        .eq('sender_id', profile.id)
        .order('created_at', { ascending: false }),
    ]);

    setReceived((recRes.data as any) || []);
    setSent((sentRes.data as any) || []);
    setLoading(false);
  };

  const handleAction = async (reqId: string, action: 'accept' | 'reject' | 'complete' | 'cancel') => {
    setActionLoading(reqId);
    const rpcMap = {
      accept: 'accept_help_request',
      reject: 'reject_help_request',
      complete: 'complete_help_request',
      cancel: 'cancel_help_request',
    };
    const { error } = await supabase.rpc(rpcMap[action], { req_id: reqId });
    setActionLoading(null);
    if (error) {
      alert(error.message);
      return;
    }
    await refreshProfile();
    loadRequests();
  };

  const handleRate = async () => {
    if (!ratingModal) return;
    setActionLoading(ratingModal.id);
    const { error } = await supabase.rpc('rate_help_request', {
      req_id: ratingModal.id,
      score: ratingScore,
    });
    setActionLoading(null);
    if (error) {
      alert(error.message);
      return;
    }
    setRatingModal(null);
    setRatingScore(5);
    loadRequests();
  };

  const statusColors: Record<string, string> = {
    pending: 'bg-amber-500/15 border-amber-500/30 text-amber-300',
    accepted: 'bg-cyan-500/15 border-cyan-500/30 text-cyan-300',
    completed: 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300',
    rejected: 'bg-rose-500/15 border-rose-500/30 text-rose-300',
    cancelled: 'bg-gray-500/15 border-gray-500/30 text-gray-400',
  };

  const renderItem = (req: ReqWithProfiles, isReceived: boolean) => {
    const otherParty = isReceived ? req.sender : req.receiver;
    const hasRated = false; // We check via simple heuristic
    return (
      <div key={req.id} className="bg-white/[0.02] rounded-2xl p-4 border border-white/[0.04]">
        <div className="flex items-start gap-3 mb-3">
          <Avatar name={otherParty.full_name} url={otherParty.avatar_url || undefined} size="md" />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="text-sm font-medium text-white">{otherParty.full_name}</p>
              <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${statusColors[req.status]}`}>
                {req.status}
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-0.5">
              {isReceived ? 'Wants help with' : 'You requested help with'} <span className="text-gray-300">{req.subject}</span>
            </p>
            <div className="flex items-center gap-2 mt-1">
              <CreditBadge amount={req.skill_credits} size="sm" />
              <span className="text-xs text-gray-600">
                {new Date(req.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
              </span>
            </div>
          </div>
        </div>

        {req.message && (
          <p className="text-sm text-gray-400 bg-white/[0.02] rounded-lg px-3 py-2 mb-3">{req.message}</p>
        )}

        {/* Actions */}
        <div className="flex gap-2 flex-wrap">
          {isReceived && req.status === 'pending' && (
            <>
              <button
                onClick={() => handleAction(req.id, 'accept')}
                disabled={actionLoading === req.id}
                className="flex-1 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold hover:bg-emerald-500/30 transition disabled:opacity-50"
              >
                Accept
              </button>
              <button
                onClick={() => handleAction(req.id, 'reject')}
                disabled={actionLoading === req.id}
                className="flex-1 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-gray-400 text-xs font-semibold hover:bg-rose-500/10 hover:text-rose-400 transition disabled:opacity-50"
              >
                Decline
              </button>
            </>
          )}
          {isReceived && req.status === 'accepted' && (
            <button
              onClick={() => handleAction(req.id, 'complete')}
              disabled={actionLoading === req.id}
              className="flex-1 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold hover:bg-emerald-500/30 transition disabled:opacity-50"
            >
              Mark Complete
            </button>
          )}
          {!isReceived && (req.status === 'pending' || req.status === 'accepted') && (
            <button
              onClick={() => handleAction(req.id, 'cancel')}
              disabled={actionLoading === req.id}
              className="flex-1 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-gray-400 text-xs font-semibold hover:bg-rose-500/10 hover:text-rose-400 transition disabled:opacity-50"
            >
              Cancel Request
            </button>
          )}
          {req.status === 'completed' && (
            <button
              onClick={() => { setRatingModal(req); setRatingScore(5); }}
              className="flex-1 py-2 rounded-lg bg-amber-500/15 border border-amber-500/25 text-amber-300 text-xs font-semibold hover:bg-amber-500/25 transition"
            >
              Rate {isReceived ? 'Student' : 'Tutor'}
            </button>
          )}
        </div>
      </div>
    );
  };

  const activeList = tab === 'received' ? received : sent;

  return (
    <div className="space-y-6">
      <div className="animate-fade-up">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">Requests</h1>
        <p className="text-gray-400 mt-1">Manage your help requests — sent and received.</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 animate-fade-up delay-100">
        <button
          onClick={() => setTab('received')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
            tab === 'received'
              ? 'bg-emerald-500/20 border border-emerald-500/30 text-emerald-300'
              : 'glass text-gray-400 hover:text-white'
          }`}
        >
          Received ({received.length})
        </button>
        <button
          onClick={() => setTab('sent')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
            tab === 'sent'
              ? 'bg-emerald-500/20 border border-emerald-500/30 text-emerald-300'
              : 'glass text-gray-400 hover:text-white'
          }`}
        >
          Sent ({sent.length})
        </button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 rounded-2xl bg-white/[0.02] animate-pulse" />
          ))}
        </div>
      ) : activeList.length === 0 ? (
        <div className="glass rounded-2xl p-12 text-center">
          <p className="text-gray-400">
            {tab === 'received' ? 'No requests received yet.' : 'You haven\'t sent any requests yet.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {activeList.map((req) => renderItem(req, tab === 'received'))}
        </div>
      )}

      {/* Rating modal */}
      {ratingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setRatingModal(null)}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
          <div className="relative w-full max-w-sm glass rounded-2xl p-6 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-white mb-1">Rate your experience</h3>
            <p className="text-sm text-gray-400 mb-4">
              How was {(tab === 'received' ? ratingModal.sender : ratingModal.receiver).full_name}?
            </p>
            <div className="flex gap-2 justify-center mb-6">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  onClick={() => setRatingScore(n)}
                  className={`text-3xl transition ${n <= ratingScore ? 'text-amber-400 scale-110' : 'text-gray-700 hover:text-gray-500'}`}
                >
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                </button>
              ))}
            </div>
            <button
              onClick={handleRate}
              disabled={actionLoading === ratingModal.id}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold hover:from-emerald-400 hover:to-teal-400 transition disabled:opacity-50"
            >
              {actionLoading === ratingModal.id ? 'Submitting...' : 'Submit Rating'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
