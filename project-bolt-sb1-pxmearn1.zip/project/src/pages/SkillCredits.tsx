import { useEffect, useState } from 'react';
import { supabase, CreditTransaction } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

export function SkillCredits() {
  const { profile } = useAuth();
  const [transactions, setTransactions] = useState<CreditTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTransactions();
  }, [profile?.id]);

  const loadTransactions = async () => {
    if (!profile) return;
    setLoading(true);
    const { data } = await supabase
      .from('credit_transactions')
      .select('*')
      .eq('profile_id', profile.id)
      .order('created_at', { ascending: false });
    setTransactions((data as CreditTransaction[]) || []);
    setLoading(false);
  };

  const earned = transactions.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  const spent = transactions.filter((t) => t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0);

  const typeIcon = (type: string) => {
    if (type === 'earned')
      return (
        <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center">
          <svg className="w-5 h-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 10l7-7m0 0l7 7m-7-7v18" />
          </svg>
        </div>
      );
    if (type === 'spent')
      return (
        <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/20 flex items-center justify-center">
          <svg className="w-5 h-5 text-rose-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      );
    return (
      <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/20 flex items-center justify-center">
        <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4-6.2-4.5-6.2 4.5 2.4-7.4L2 9.4h7.6z" />
        </svg>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="animate-fade-up">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">Skill Credits</h1>
        <p className="text-gray-400 mt-1">Your learning currency. Earn by helping, spend to get help.</p>
      </div>

      {/* Balance card */}
      <div className="glass rounded-2xl p-6 card-glow animate-fade-up delay-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-[60px]" />
        <div className="relative">
          <p className="text-xs text-gray-500 font-medium mb-2">Current Balance</p>
          <div className="flex items-center gap-3">
            <span className="text-5xl font-bold gradient-text">{profile?.skill_credits ?? 0}</span>
            <span className="text-lg text-gray-500 font-medium">credits</span>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-6">
            <div className="bg-white/[0.03] rounded-xl p-3 border border-white/[0.04]">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs text-gray-500">Total Earned</span>
              </div>
              <p className="text-xl font-bold text-emerald-400">+{earned}</p>
            </div>
            <div className="bg-white/[0.03] rounded-xl p-3 border border-white/[0.04]">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-2 h-2 rounded-full bg-rose-400" />
                <span className="text-xs text-gray-500">Total Spent</span>
              </div>
              <p className="text-xl font-bold text-rose-400">-{spent}</p>
            </div>
          </div>
        </div>
      </div>

      {/* How it works */}
      <div className="grid sm:grid-cols-2 gap-4 animate-fade-up delay-200">
        <div className="glass rounded-2xl p-5">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center mb-3">
            <svg className="w-5 h-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 10l7-7m0 0l7 7m-7-7v18" />
            </svg>
          </div>
          <h3 className="font-semibold text-white text-sm mb-1">How to earn credits</h3>
          <p className="text-xs text-gray-400">Accept help requests from other students and complete sessions. Each completed request adds credits to your balance.</p>
        </div>
        <div className="glass rounded-2xl p-5">
          <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/20 flex items-center justify-center mb-3">
            <svg className="w-5 h-5 text-rose-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
          <h3 className="font-semibold text-white text-sm mb-1">How credits are spent</h3>
          <p className="text-xs text-gray-400">When you request help, you offer credits. They're escrowed when accepted and transferred to your helper on completion.</p>
        </div>
      </div>

      {/* Transaction history */}
      <div className="glass rounded-2xl p-5 animate-fade-up delay-300">
        <h2 className="font-semibold text-white mb-4">Transaction History</h2>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-14 rounded-xl bg-white/[0.02] animate-pulse" />
            ))}
          </div>
        ) : transactions.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p className="text-sm">No transactions yet. Start helping or requesting to see activity here.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {transactions.map((t) => (
              <div key={t.id} className="flex items-center gap-3 bg-white/[0.02] rounded-xl p-3 border border-white/[0.04]">
                {typeIcon(t.type)}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{t.description}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(t.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </p>
                </div>
                <span className={`text-lg font-bold ${t.amount > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {t.amount > 0 ? '+' : ''}{t.amount}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
