import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Avatar } from '@/components/ui';

export function Settings() {
  const { profile, user, signOut } = useAuth();
  const [newName, setNewName] = useState('');
  const [savingName, setSavingName] = useState(false);
  const [nameSaved, setNameSaved] = useState(false);

  const handleUpdateName = async () => {
    if (!user || !newName.trim()) return;
    setSavingName(true);
    await supabase.from('profiles').update({ full_name: newName }).eq('id', user.id);
    setSavingName(false);
    setNewName('');
    setNameSaved(true);
    setTimeout(() => setNameSaved(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="animate-fade-up">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">Settings</h1>
        <p className="text-gray-400 mt-1">Manage your account and preferences.</p>
      </div>

      {/* Account info */}
      <div className="glass rounded-2xl p-6 animate-fade-up delay-100">
        <h2 className="font-semibold text-white mb-4">Account</h2>
        <div className="flex items-center gap-4 mb-5">
          <Avatar name={profile?.full_name || 'User'} url={profile?.avatar_url || undefined} size="lg" />
          <div>
            <p className="font-medium text-white">{profile?.full_name}</p>
            <p className="text-sm text-gray-500">{profile?.email}</p>
          </div>
        </div>

        <div className="space-y-3 border-t border-white/[0.06] pt-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">Education Level</span>
            <span className="text-sm text-white">{profile?.education_level || 'Not set'}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">City</span>
            <span className="text-sm text-white">{profile?.city || 'Not set'}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">Skill Credits</span>
            <span className="text-sm font-semibold text-emerald-400">{profile?.skill_credits}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">Rating</span>
            <span className="text-sm text-white">
              {profile && profile.rating_avg > 0 ? `${profile.rating_avg.toFixed(1)} (${profile.rating_count} reviews)` : 'No ratings yet'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">Member since</span>
            <span className="text-sm text-white">
              {profile ? new Date(profile.created_at).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' }) : ''}
            </span>
          </div>
        </div>
      </div>

      {/* Update name */}
      <div className="glass rounded-2xl p-6 animate-fade-up delay-200">
        <h2 className="font-semibold text-white mb-4">Update Name</h2>
        <div className="flex gap-3">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder={profile?.full_name || 'Enter new name'}
            className="flex-1 bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition"
          />
          <button
            onClick={handleUpdateName}
            disabled={savingName || !newName.trim()}
            className="px-5 py-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-sm font-semibold hover:bg-emerald-500/30 transition disabled:opacity-50"
          >
            {savingName ? 'Saving...' : nameSaved ? 'Saved!' : 'Update'}
          </button>
        </div>
      </div>

      {/* About */}
      <div className="glass rounded-2xl p-6 animate-fade-up delay-300">
        <h2 className="font-semibold text-white mb-3">About StudySwap</h2>
        <p className="text-sm text-gray-400 leading-relaxed">
          StudySwap is a peer-to-peer learning platform where students exchange knowledge using Skill Credits instead of money.
          Help a fellow student to earn credits, then spend them to get help with subjects you struggle with.
        </p>
        <p className="text-xs text-gray-600 mt-4">Version 1.0 · Built for students in India</p>
      </div>

      {/* Sign out */}
      <div className="animate-fade-up delay-300">
        <button
          onClick={signOut}
          className="w-full py-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 font-semibold hover:bg-rose-500/20 transition flex items-center justify-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
          </svg>
          Sign Out
        </button>
      </div>
    </div>
  );
}
