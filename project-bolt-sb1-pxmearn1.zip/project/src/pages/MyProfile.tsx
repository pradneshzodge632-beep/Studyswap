import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { SUBJECTS, EDUCATION_LEVELS, CITIES } from '@/lib/constants';
import { Avatar, RatingStars, SkillTag } from '@/components/ui';

export function MyProfile() {
  const { profile, user, refreshProfile } = useAuth();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [avatarUrl, setAvatarUrl] = useState(profile?.avatar_url || '');
  const [educationLevel, setEducationLevel] = useState(profile?.education_level || '');
  const [city, setCity] = useState(profile?.city || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [skillsTeach, setSkillsTeach] = useState<string[]>(profile?.skills_teach || []);
  const [skillsLearn, setSkillsLearn] = useState<string[]>(profile?.skills_learn || []);

  const toggleSkill = (skill: string, list: string[], setter: (v: string[]) => void) => {
    setter(list.includes(skill) ? list.filter((s) => s !== skill) : [...list, skill]);
  };

  const handleSave = async () => {
    if (!user) return;
    if (!fullName.trim()) {
      setError('Name cannot be empty');
      return;
    }
    setSaving(true);
    setError(null);
    const { error: e } = await supabase
      .from('profiles')
      .update({
        full_name: fullName,
        avatar_url: avatarUrl,
        education_level: educationLevel,
        city,
        bio,
        skills_teach: skillsTeach,
        skills_learn: skillsLearn,
        onboarded: true,
      })
      .eq('id', user.id);
    setSaving(false);
    if (e) {
      setError(e.message);
      return;
    }
    await refreshProfile();
    setEditing(false);
  };

  const startEditing = () => {
    setFullName(profile?.full_name || '');
    setAvatarUrl(profile?.avatar_url || '');
    setEducationLevel(profile?.education_level || '');
    setCity(profile?.city || '');
    setBio(profile?.bio || '');
    setSkillsTeach(profile?.skills_teach || []);
    setSkillsLearn(profile?.skills_learn || []);
    setEditing(true);
  };

  if (!profile) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between animate-fade-up">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white">My Profile</h1>
          <p className="text-gray-400 mt-1">Manage your study profile and skills.</p>
        </div>
        {!editing && (
          <button
            onClick={startEditing}
            className="px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-sm font-semibold hover:bg-emerald-500/30 transition"
          >
            Edit Profile
          </button>
        )}
      </div>

      {editing ? (
        /* Edit mode */
        <div className="glass rounded-2xl p-6 space-y-5 animate-fade-up delay-100">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1.5">Full Name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1.5">Avatar URL</label>
              <input
                type="url"
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="https://..."
                className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition"
              />
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1.5">Education Level</label>
              <select
                value={educationLevel}
                onChange={(e) => setEducationLevel(e.target.value)}
                className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
              >
                <option value="" className="bg-[#0a0a0f]">Select level</option>
                {EDUCATION_LEVELS.map((l) => <option key={l} value={l} className="bg-[#0a0a0f]">{l}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1.5">City</label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
              >
                <option value="" className="bg-[#0a0a0f]">Select city</option>
                {CITIES.map((c) => <option key={c} value={c} className="bg-[#0a0a0f]">{c}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Bio</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              maxLength={200}
              className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-400 mb-2">Can teach</label>
            <div className="flex flex-wrap gap-2">
              {SUBJECTS.map((s) => (
                <button
                  key={s}
                  onClick={() => toggleSkill(s, skillsTeach, setSkillsTeach)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                    skillsTeach.includes(s) ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300' : 'bg-white/[0.03] border-white/10 text-gray-400 hover:border-white/20'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-400 mb-2">Needs help with</label>
            <div className="flex flex-wrap gap-2">
              {SUBJECTS.map((s) => (
                <button
                  key={s}
                  onClick={() => toggleSkill(s, skillsLearn, setSkillsLearn)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                    skillsLearn.includes(s) ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300' : 'bg-white/[0.03] border-white/10 text-gray-400 hover:border-white/20'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="text-sm text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-xl px-3 py-2">{error}</div>
          )}

          <div className="flex gap-3">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold hover:from-emerald-400 hover:to-teal-400 transition disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
            <button
              onClick={() => setEditing(false)}
              className="px-6 py-3 rounded-xl glass text-gray-300 font-semibold hover:bg-white/[0.06] transition"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        /* View mode */
        <div className="space-y-5">
          {/* Profile header */}
          <div className="glass rounded-2xl p-6 animate-fade-up delay-100">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <Avatar name={profile.full_name} url={profile.avatar_url || undefined} size="xl" />
              <div className="flex-1 text-center sm:text-left">
                <h2 className="text-2xl font-bold text-white">{profile.full_name}</h2>
                <p className="text-sm text-gray-500 mt-1">{profile.email}</p>
                <div className="flex items-center gap-3 mt-2 justify-center sm:justify-start">
                  <span className="text-sm text-gray-400">{profile.education_level}</span>
                  <span className="text-gray-600">·</span>
                  <span className="text-sm text-gray-400">{profile.city}</span>
                </div>
                <div className="flex items-center gap-4 mt-3 justify-center sm:justify-start">
                  <RatingStars rating={profile.rating_avg} count={profile.rating_count} size="md" />
                </div>
              </div>
              <div className="text-center">
                <p className="text-xs text-gray-500 mb-1">Credits</p>
                <span className="text-3xl font-bold gradient-text">{profile.skill_credits}</span>
              </div>
            </div>

            {profile.bio && (
              <p className="text-sm text-gray-400 mt-5 leading-relaxed border-t border-white/[0.06] pt-5">{profile.bio}</p>
            )}
          </div>

          {/* Skills */}
          <div className="grid sm:grid-cols-2 gap-5">
            <div className="glass rounded-2xl p-5 animate-fade-up delay-200">
              <h3 className="font-semibold text-white mb-3">Can Teach</h3>
              {profile.skills_teach.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {profile.skills_teach.map((s) => <SkillTag key={s} skill={s} variant="teach" />)}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No teaching skills added yet.</p>
              )}
            </div>
            <div className="glass rounded-2xl p-5 animate-fade-up delay-200">
              <h3 className="font-semibold text-white mb-3">Needs Help With</h3>
              {profile.skills_learn.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {profile.skills_learn.map((s) => <SkillTag key={s} skill={s} variant="learn" />)}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No learning subjects added yet.</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
