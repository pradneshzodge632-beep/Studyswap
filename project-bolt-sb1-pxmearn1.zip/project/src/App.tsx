import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { LandingPage } from '@/pages/LandingPage';
import { AuthPage } from '@/pages/AuthPage';
import { OnboardingPage } from '@/pages/OnboardingPage';
import { AppLayout } from '@/components/AppLayout';
import { Dashboard } from '@/pages/Dashboard';
import { FindStudents } from '@/pages/FindStudents';
import { MyProfile } from '@/pages/MyProfile';
import { Requests } from '@/pages/Requests';
import { SkillCredits } from '@/pages/SkillCredits';
import { Settings } from '@/pages/Settings';

type Page = 'dashboard' | 'find' | 'profile' | 'requests' | 'credits' | 'settings';
type View = 'landing' | 'auth';

function AppContent() {
  const { session, profile, loading } = useAuth();
  const [view, setView] = useState<View>('landing');
  const [authMode, setAuthMode] = useState<'signup' | 'login'>('signup');
  const [page, setPage] = useState<Page>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center animate-pulse">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.5 3.5 8.5 2 6 2C3.5 2 1.5 3.5 0 6.253C1.5 9 3.5 10.5 6 10.5c2.5 0 4.5-1.5 6-4.247zM12 6.253C13.5 3.5 15.5 2 18 2c2.5 0 4.5 1.5 6 4.253C22.5 9 20.5 10.5 18 10.5c-2.5 0-4.5-1.5-6-4.247z" />
            </svg>
          </div>
          <p className="text-sm text-gray-500">Loading...</p>
        </div>
      </div>
    );
  }

  // Authenticated user
  if (session && profile) {
    // Not onboarded yet — show onboarding
    if (!profile.onboarded) {
      return <OnboardingPage onComplete={() => setPage('dashboard')} />;
    }

    // Main app
    return (
      <AppLayout activePage={page} onNavigate={setPage}>
        {page === 'dashboard' && <Dashboard onNavigate={setPage} />}
        {page === 'find' && <FindStudents />}
        {page === 'profile' && <MyProfile />}
        {page === 'requests' && <Requests />}
        {page === 'credits' && <SkillCredits />}
        {page === 'settings' && <Settings />}
      </AppLayout>
    );
  }

  // Not authenticated — show landing or auth
  if (view === 'auth') {
    return (
      <AuthPage
        initialMode={authMode}
        onSuccess={() => setView('landing')}
        onBack={() => setView('landing')}
      />
    );
  }

  return (
    <LandingPage
      onGetStarted={() => {
        setAuthMode('signup');
        setView('auth');
      }}
      onFindPartner={() => {
        setAuthMode('login');
        setView('auth');
      }}
    />
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
