import { Profile } from '@/lib/supabase';

const COLORS = [
  'from-emerald-500/20 to-teal-500/20 text-emerald-300 border-emerald-500/30',
  'from-cyan-500/20 to-blue-500/20 text-cyan-300 border-cyan-500/30',
  'from-amber-500/20 to-orange-500/20 text-amber-300 border-amber-500/30',
  'from-rose-500/20 to-pink-500/20 text-rose-300 border-rose-500/30',
  'from-violet-500/20 to-indigo-500/20 text-violet-300 border-violet-500/30',
  'from-lime-500/20 to-green-500/20 text-lime-300 border-lime-500/30',
];

function hashIndex(str: string, mod: number) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % mod;
  return h;
}

export function SkillTag({ skill, variant = 'teach' }: { skill: string; variant?: 'teach' | 'learn' }) {
  const colorIdx = hashIndex(skill, COLORS.length);
  const base = COLORS[colorIdx];
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-gradient-to-br ${base} border`}
    >
      {variant === 'teach' ? (
        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
        </svg>
      ) : (
        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
        </svg>
      )}
      {skill}
    </span>
  );
}

export function Avatar({
  name,
  url,
  size = 'md',
}: {
  name: string;
  url?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}) {
  const sizes = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-lg',
    xl: 'w-24 h-24 text-3xl',
  };
  const initials = name
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
  const colorIdx = hashIndex(name, COLORS.length);
  const colorClass = COLORS[colorIdx];

  if (url) {
    return <img src={url} alt={name} className={`${sizes[size]} rounded-full object-cover border border-white/10`} />;
  }
  return (
    <div
      className={`${sizes[size]} rounded-full flex items-center justify-center font-semibold bg-gradient-to-br ${colorClass} border`}
    >
      {initials}
    </div>
  );
}

export function RatingStars({ rating, count, size = 'sm' }: { rating: number; count?: number; size?: 'sm' | 'md' }) {
  const starSize = size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4';
  return (
    <div className="flex items-center gap-1">
      <svg className={`${starSize} text-amber-400`} fill="currentColor" viewBox="0 0 20 20">
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
      </svg>
      <span className={`font-semibold ${size === 'sm' ? 'text-xs' : 'text-sm'} text-amber-400`}>
        {rating > 0 ? rating.toFixed(1) : 'New'}
      </span>
      {count !== undefined && count > 0 && (
        <span className="text-xs text-gray-500">({count})</span>
      )}
    </div>
  );
}

export function CreditBadge({ amount, size = 'md' }: { amount: number; size?: 'sm' | 'md' | 'lg' }) {
  const sizes = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-2.5 py-1',
    lg: 'text-base px-3 py-1.5',
  };
  return (
    <span className={`inline-flex items-center gap-1 ${sizes[size]} rounded-full bg-gradient-to-r from-emerald-500/15 to-teal-500/15 border border-emerald-500/25 text-emerald-300 font-semibold`}>
      <svg className={size === 'sm' ? 'w-3 h-3' : 'w-4 h-4'} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4-6.2-4.5-6.2 4.5 2.4-7.4L2 9.4h7.6z" />
      </svg>
      {amount}
    </span>
  );
}

export function ProfileCard({ profile }: { profile: Profile }) {
  return (
    <div className="flex items-center gap-3">
      <Avatar name={profile.full_name} url={profile.avatar_url || undefined} size="lg" />
      <div>
        <h3 className="font-semibold text-white">{profile.full_name}</h3>
        <p className="text-sm text-gray-400">{profile.education_level} · {profile.city}</p>
      </div>
    </div>
  );
}
