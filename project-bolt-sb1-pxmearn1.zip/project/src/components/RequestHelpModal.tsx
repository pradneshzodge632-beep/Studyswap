import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { MatchedStudent } from '@/lib/supabase';

export function RequestHelpModal({
  student,
  onClose,
  onSent,
}: {
  student: MatchedStudent;
  onClose: () => void;
  onSent: () => void;
}) {
  const { profile } = useAuth();
  const [subject, setSubject] = useState(
    student.skills_teach.length > 0 ? student.skills_teach[0] : ''
  );
  const [message, setMessage] = useState('');
  const [credits, setCredits] = useState(1);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSend = async () => {
    if (!profile) return;
    if (credits < 1) {
      setError('Must offer at least 1 credit');
      return;
    }
    if (credits > profile.skill_credits) {
      setError(`You only have ${profile.skill_credits} credits`);
      return;
    }
    setSending(true);
    setError(null);
    const { error: e } = await supabase.from('help_requests').insert({
      sender_id: profile.id,
      receiver_id: student.id,
      subject,
      message,
      skill_credits: credits,
      status: 'pending',
    });
    setSending(false);
    if (e) {
      setError(e.message);
      return;
    }
    onSent();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-md glass rounded-2xl p-6 animate-scale-in card-glow"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-5">
          <div>
            <h3 className="text-lg font-bold text-white">Request Help</h3>
            <p className="text-sm text-gray-400 mt-0.5">From {student.full_name}</p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-white transition">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Subject</label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500/50 transition"
            >
              {student.skills_teach.map((s) => (
                <option key={s} value={s} className="bg-[#0a0a0f]">
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Message (optional)</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={3}
              placeholder="Briefly describe what you need help with..."
              className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Skill Credits to offer
            </label>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCredits((c) => Math.max(1, c - 1))}
                className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/10 text-white hover:bg-white/[0.08] transition flex items-center justify-center"
              >
                –
              </button>
              <div className="flex-1 text-center">
                <span className="text-2xl font-bold gradient-text">{credits}</span>
                <p className="text-xs text-gray-500 mt-0.5">
                  Balance: {profile?.skill_credits ?? 0}
                </p>
              </div>
              <button
                onClick={() => setCredits((c) => Math.min(profile?.skill_credits ?? 1, c + 1))}
                className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/10 text-white hover:bg-white/[0.08] transition flex items-center justify-center"
              >
                +
              </button>
            </div>
          </div>

          {error && (
            <div className="text-sm text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-xl px-3 py-2">
              {error}
            </div>
          )}

          <button
            onClick={handleSend}
            disabled={sending}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold hover:from-emerald-400 hover:to-teal-400 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {sending ? 'Sending...' : 'Send Request'}
          </button>
        </div>
      </div>
    </div>
  );
}
