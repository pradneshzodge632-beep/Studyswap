export const SUBJECTS = [
  'Mathematics',
  'Physics',
  'Chemistry',
  'Biology',
  'Computer Science',
  'Python',
  'Web Development',
  'Data Science',
  'Statistics',
  'English',
  'History',
  'Political Science',
  'Economics',
  'Business Studies',
  'Accountancy',
  'Psychology',
  'Sociology',
  'Geography',
];

export const EDUCATION_LEVELS = [
  'Class 11',
  'Class 12',
  'Undergraduate',
  'Postgraduate',
];

export const CITIES = [
  'Mumbai',
  'Delhi',
  'Bengaluru',
  'Hyderabad',
  'Chennai',
  'Kolkata',
  'Pune',
  'Jaipur',
  'Ahmedabad',
  'Lucknow',
  'Chandigarh',
  'Other',
];
