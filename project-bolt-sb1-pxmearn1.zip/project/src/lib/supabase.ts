import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Profile = {
  id: string;
  email: string;
  full_name: string;
  avatar_url: string;
  education_level: string;
  city: string;
  skills_teach: string[];
  skills_learn: string[];
  bio: string;
  skill_credits: number;
  rating_avg: number;
  rating_count: number;
  onboarded: boolean;
  created_at: string;
  updated_at: string;
};

export type HelpRequest = {
  id: string;
  sender_id: string;
  receiver_id: string;
  subject: string;
  message: string;
  status: 'pending' | 'accepted' | 'rejected' | 'completed' | 'cancelled';
  skill_credits: number;
  created_at: string;
  updated_at: string;
};

export type CreditTransaction = {
  id: string;
  profile_id: string;
  amount: number;
  type: 'earned' | 'spent' | 'bonus';
  description: string;
  related_request_id: string | null;
  created_at: string;
};

export type MatchedStudent = {
  id: string;
  full_name: string;
  avatar_url: string;
  education_level: string;
  city: string;
  skills_teach: string[];
  skills_learn: string[];
  bio: string;
  rating_avg: number;
  rating_count: number;
  match_score: number;
};
